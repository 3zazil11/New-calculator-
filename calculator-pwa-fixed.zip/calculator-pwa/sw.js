const CACHE_NAME = 'calculator-v2';
const FILES = [
  '/New-calculator-/',
  '/New-calculator-/index.html',
  '/New-calculator-/manifest.json',
  '/New-calculator-/icons/icon-192x192.png',
  '/New-calculator-/icons/icon-512x512.png'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(FILES)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
  ));
});

self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
